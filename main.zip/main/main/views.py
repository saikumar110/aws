

from django.http import HttpResponse
from django.contrib.staticfiles.storage import staticfiles_storage
import os
import pandas as pd


def Home(request):
    df  = pd.read_csv( (staticfiles_storage.path("fo11FEB2022bhav.csv")))
    
    # # html= df.to_dict()
    # print(html)
    return HttpResponse("html")